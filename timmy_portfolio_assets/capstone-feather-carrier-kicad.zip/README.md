# Feather 32u4 sensor carrier — ground-routing revision

This capstone prototype carrier sockets an Adafruit Feather 32u4 and connects an
AHT30 digital temperature breakout and a MAX30102 optical pulse-sensing breakout
over I²C. This is not the analog NTC thermistor circuit shown in the design-review
LTspice simulations.

The revision connects both breakout ground pads to the Feather ground using
0.30 mm back-copper traces and existing plated-through holes. The front ground
zone was refilled and isolated copper removed. The unused second ground pin on
the Feather socket remains intentionally unrouted; its label matches the
[Adafruit Rev B schematic](https://github.com/adafruit/Adafruit-Feather-32u4-Basic-Proto-PCB/blob/master/Adafruit%20Feather%2032u4%20Basic%20rev%20B.sch).

Open the included .kicad_pro in KiCad 9 with the project symbol library and
sym-lib-table in the same directory. KiCad 9.0.7 reported zero PCB DRC violations,
unrouted items, schematic parity issues, and schematic ERC violations.

This is a checked layout revision, not a bench-validated or clinical device.
Verify your physical breakout pin order, power requirements, and fit before
use. Do not reuse fabrication files exported before the grounding revision.
